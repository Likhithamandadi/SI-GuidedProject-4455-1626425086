# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 12:51:16 2020

@author: ammuk
"""

<html>
<style>


*{
	margin:0;
	padding:0;
	text-decoration:none;
	font-family:montserrat;
}
.pd{
padding-bottom:100%;}
body
{
background-image:url('https://acegif.com/wp-content/gifs/water-43.gif');
background-position: center;
font-family:sans-serif;
background-size:cover;
margin-top:40px;
}


.main{
	background-color:rgb(0,0,0,0.6);
	width:800px;
	height:500px;
	margin:auto;
	position:center;
	border-top-left-radius:100px;
	border-bottom-right-radius:100px;

}
.main input[type="text"],.main input[type="text"],.main input[type="text"],.main input[type="text"],.main input[type="text"],.main input[type="text"]{
	border:0;
	background:none;
	display:block;
	margin:20px auto;
	text-align:center;
	border:2px solid #3498db;
	padding:10px 3px;
	width:200px;
	outline:none;
	color:white;
	border-radius:24px;
	transition:0.25s;
	
}
.main input[type="text"]:focus,.main input[type="text"]:focus,.main input[type="text"]:focus,.main input[type="text"]:focus,.main input[type="text"]:focus,.main input[type="text"]:focus{
	width:280px;
	border-color:#8e44ad;
}
.logbtn{
	display:block;
	width:35%;
	height:50px;
	border:none;
	border-radius:24px;
	background:linear-gradient(120deg,#3498db,#8e44ad,#3498db);
	background-size:200%;
	color:#fff;
	outline:none;
	cursor:pointer;
	transition:.5s;
}
.logbtn:hover{
	background-position:right;
}
.bottom-text{
	margin-top:60px;
	text-align:center;
	font-size:13px;

}

